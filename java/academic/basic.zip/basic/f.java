package academic.basic;

public class f {
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.print("Harshit Sinha");
    }
    
}
