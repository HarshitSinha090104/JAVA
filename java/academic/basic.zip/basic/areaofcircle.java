package academic.basic;

public class areaofcircle {
    public static void main(String[] args) {
        double a=7.5;
        System.out.println(3.14*a*a);

    }
}
