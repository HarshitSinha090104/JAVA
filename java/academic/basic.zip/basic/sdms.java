package academic.basic;

public class sdms {
    public static void main(String[] args) {
        int a=125;
        int b=24;
        System.out.println(a/b);
        System.out.println(a*b);
        System.out.println(a+b);
        System.out.println(a-b);
    }
}
