package academic.basic;
import java.util.*;
public class average {
    public static void main(String[] args) {
        Scanner inp=new Scanner(System.in);
        int a=inp.nextInt();
        int b=inp.nextInt();
        int c=inp.nextInt();
        System.out.println((a+b+c)/3);

    }
}
